import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'price_management_page.dart'; // 👈 nhớ import trang bảng giá

class DevicesPage extends StatefulWidget {
  const DevicesPage({super.key});

  @override
  State<DevicesPage> createState() => _DevicesPageState();
}

class _DevicesPageState extends State<DevicesPage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref('devices');
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _roomController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _roomController.dispose();
    super.dispose();
  }

  // Hộp thoại thêm thiết bị
  void _showAddDeviceDialog() {
    _nameController.clear();
    _roomController.clear();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Add Device'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Device Name'),
            ),
            TextField(
              controller: _roomController,
              decoration: const InputDecoration(labelText: 'Room'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final name = _nameController.text.trim();
              final room = _roomController.text.trim();
              if (name.isNotEmpty && room.isNotEmpty) {
                await _dbRef.push().set({
                  'name': name,
                  'room': room,
                  'isOn': false,
                });
              }
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple[200],
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  // 🆕 Hàm chọn loại hành động khi bấm nút +
  void _showAddOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.devices_other, color: Colors.blue),
                title: const Text('Add New Device'),
                onTap: () {
                  Navigator.pop(context);
                  _showAddDeviceDialog();
                },
              ),
              ListTile(
                leading: const Icon(Icons.price_change, color: Colors.green),
                title: const Text('Open Price Management'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const PriceManagementPage(),
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _toggleDevice(String key, bool isOn) {
    _dbRef.child(key).update({'isOn': !isOn});
  }

  void _confirmDelete(String key, String name) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text("Delete Device"),
          content: Text('Are you sure you want to delete "$name"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {
                await _dbRef.child(key).remove();
                if (context.mounted) Navigator.pop(context);
              },
              style: ButtonStyle(
                foregroundColor: MaterialStateProperty.resolveWith<Color>(
                      (states) => states.contains(MaterialState.hovered)
                      ? Colors.red.shade700
                      : Colors.red.shade300,
                ),
              ),
              child: const Text("Delete"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Devices"),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _showAddOptions, // 👈 đổi hàm ở đây
          ),
        ],
      ),
      body: StreamBuilder<DatabaseEvent>(
        stream: _dbRef.onValue,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
            return const Center(child: Text("No devices added."));
          }

          final Map<String, dynamic> devicesMap =
          Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);

          return GridView.count(
            crossAxisCount: 2,
            padding: const EdgeInsets.all(12),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            children: devicesMap.entries.map((entry) {
              final key = entry.key;
              final data = Map<String, dynamic>.from(entry.value);
              final bool isOn = data['isOn'] ?? false;

              return GestureDetector(
                onTap: () => _confirmDelete(key, data['name'] ?? 'device'),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        const Icon(Icons.devices_other, size: 40),
                        Text(data['name'] ?? '',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        Text(data['room'] ?? '',
                            style: const TextStyle(
                                fontSize: 14, color: Colors.grey)),
                        Switch(
                          value: isOn,
                          onChanged: (_) => _toggleDevice(key, isOn),
                          activeColor: Colors.greenAccent,
                        )
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}