import 'package:flutter/material.dart';
import 'package:app/pagetool/dartmode.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'pagelogin/login.dart'; // Trang đăng nhập của bạn
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 🔥 Khởi tạo Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeNotifier = Provider.of<ThemeNotifier>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ProHome',

      // 🌙 Theme
      theme: ThemeData(
        brightness: Brightness.light,
        fontFamily: 'Roboto', // ✅ Giúp hiển thị và nhập tiếng Việt có dấu chuẩn
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'Roboto', // ✅ Dùng font hỗ trợ Unicode
      ),
      themeMode: themeNotifier.currentTheme, // 👈 Chuyển theme động

      // 🏠 Trang khởi đầu
      home: const LoginPage(),

      // ⚙️ Fix lỗi hiển thị ký tự Unicode và căn chữ
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.ltr,
          child: MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: child!,
          ),
        );
      },
    );
  }
}