import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final DatabaseReference devicesRef = FirebaseDatabase.instance.ref('devices');
  final DatabaseReference energyRef = FirebaseDatabase.instance.ref('energy/kwh');

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textColor = theme.textTheme.bodyLarge?.color ?? Colors.black;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.appBarTheme.backgroundColor ?? theme.scaffoldBackgroundColor,
        title: const Text(
          'ProHome',
          style: TextStyle(
            color: Colors.purple,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hiển thị điện năng
            StreamBuilder<DatabaseEvent>(
              stream: energyRef.onValue,
              builder: (context, snapshot) {
                final kwh = snapshot.data?.snapshot.value ?? 0;
                return Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF114D44),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.flash_on, color: Colors.greenAccent, size: 32),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('$kwh kWh', style: TextStyle(color: textColor, fontSize: 18)),
                          const SizedBox(height: 4),
                          Text('Electricity usage of this month',
                              style: TextStyle(color: textColor.withOpacity(0.7), fontSize: 12)),
                        ],
                      )
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Text('Linked Devices', style: TextStyle(color: textColor, fontSize: 16)),
            const SizedBox(height: 16),

            // Gộp thiết bị theo tên
            Expanded(
              child: StreamBuilder<DatabaseEvent>(
                stream: devicesRef.onValue,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
                    return const Center(child: Text('No devices found'));
                  }

                  final Map rawDevices = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);

                  // Gộp theo 'name'
                  final Map<String, List<Map<String, dynamic>>> groupedDevices = {};
                  rawDevices.forEach((key, value) {
                    final device = Map<String, dynamic>.from(value);
                    final name = device['name'] ?? 'Unknown';
                    if (!groupedDevices.containsKey(name)) {
                      groupedDevices[name] = [];
                    }
                    device['key'] = key;
                    groupedDevices[name]!.add(device);
                  });

                  final totalDevices = rawDevices.length;
                  final activeDevices = rawDevices.values.where((e) => (e['isOn'] ?? false) == true).length;

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$activeDevices / $totalDevices thiết bị đang bật',
                        style: TextStyle(color: textColor.withOpacity(0.7), fontSize: 14),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: GridView.count(
                          crossAxisCount: 2,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 16,
                          children: groupedDevices.entries.map((entry) {
                            final name = entry.key;
                            final devices = entry.value;
                            final isOn = devices.every((d) => d['isOn'] == true);

                            return DeviceGroupCard(
                              name: name,
                              isOn: isOn,
                              deviceKeys: devices.map((d) => d['key'] as String).toList(),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Widget hiển thị ô gộp thiết bị
class DeviceGroupCard extends StatefulWidget {
  final String name;
  final bool isOn;
  final List<String> deviceKeys;

  const DeviceGroupCard({
    super.key,
    required this.name,
    required this.isOn,
    required this.deviceKeys,
  });

  @override
  State<DeviceGroupCard> createState() => _DeviceGroupCardState();
}

class _DeviceGroupCardState extends State<DeviceGroupCard> {
  late bool isOn;

  @override
  void initState() {
    super.initState();
    isOn = widget.isOn;
  }

  void _toggleGroup(bool value) async {
    setState(() => isOn = value);
    for (final key in widget.deviceKeys) {
      await FirebaseDatabase.instance.ref('devices/$key').update({'isOn': value});
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final textColor = isDark ? Colors.white : Colors.black;
    final subTextColor = isDark ? Colors.grey[400]! : Colors.grey[600]!;
    final cardColor = isDark ? const Color(0xFF1A1A1D) : Colors.grey[100]!;

    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: isDark ? Colors.black45 : Colors.black12,
            blurRadius: 6,
            offset: const Offset(0, 4),
          )
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Icon(Icons.devices_other, color: textColor, size: 32),
          const SizedBox(height: 10),
          Text(
            widget.name,
            style: TextStyle(
              color: textColor,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            "Tất cả thiết bị",
            style: TextStyle(color: subTextColor, fontSize: 13),
          ),
          const SizedBox(height: 10),
          Switch(
            value: isOn,
            activeColor: Colors.greenAccent,
            inactiveThumbColor: isDark ? Colors.grey[700] : Colors.grey[400],
            inactiveTrackColor: isDark ? Colors.grey[800] : Colors.grey[300],
            onChanged: _toggleGroup,
          ),
        ],
      ),
    );
  }
}

